# Smart Billing Android Project (starter source)

This is a starter Android project for local billing and Bluetooth Classic receipt printing.

## Features in this starter
- Native Android Kotlin/Java-style app shell (Java source)
- Menu item add/delete and local preferences
- Takeaway and dine-in/table billing
- Cash or UPI marked for manual verification
- Bill receipt formatting, history during current app session, reprint
- Paired Bluetooth device selection and ESC/POS-style test printing
- GitHub Actions workflow to build a debug APK

## Important limitations
This is NOT a tested, production-ready APK. The APK must be built and the printer tested on the user's Android phone.
- Customer QR ordering and real-time cross-phone order sync are NOT included in this native starter. They require a hosted customer ordering page and a shared backend/database.
- UPI QR generation and payment confirmation are NOT implemented. A UPI QR must be configured, and payment should be verified before marking paid.
- Printer compatibility is not guaranteed for every SR588 variant. The code tries Bluetooth Classic SPP and ESC/POS text; some variants need a vendor-specific protocol/library.
- This starter's order history is held in memory and is not reloaded after app restart yet. Menu/shop settings persist locally.
- No tax invoice/GST compliance is implied. Configure fields and consult an accountant if issuing tax invoices.

## Build from Android phone using GitHub
1. Create/sign in to GitHub in your phone browser.
2. Create a new repository (e.g. `smart-billing-android`).
3. Upload the contents of this ZIP to the repository root (not the ZIP itself).
4. Open the repository's Actions tab and run **Build Smart Billing APK** (or push to `main`).
5. When the workflow completes, open its run, scroll to Artifacts, and download `SmartBilling-debug-apk`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask permission to install unknown apps from the browser/files app.
7. Open Smart Billing → Printer → Find paired printers → select SR588 → Test print.

If the build fails, inspect the Actions log; the workflow/build setup may need adjustments for the repository's Gradle wrapper and Android build environment.

## Safer next improvements
- Add Gradle wrapper files
- Persist bill history in SQLite/Room
- Add a hosted customer QR website and Firebase/Firestore backend
- Add proper UPI QR and payment provider verification
- Add automatic print retry and printer model-specific protocol support
