package com.smartbilling.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ_BT = 88;
    private final String PREF = "smart_billing";
    private final ArrayList<Item> menu = new ArrayList<>();
    private final ArrayList<Order> orders = new ArrayList<>();
    private LinearLayout root, content;
    private TextView totalText, printerStatus;
    private EditText shopName, customerName, tableNo;
    private Spinner paymentSpinner, modeSpinner;
    private BluetoothDevice selectedPrinter;
    private String connectedName = "Not connected";
    private final HashMap<Integer,Integer> cart = new HashMap<>();
    private SharedPreferences prefs;

    static class Item {
        int id; String name, category; double price;
        Item(int id,String name,String category,double price){this.id=id;this.name=name;this.category=category;this.price=price;}
    }
    static class Order {
        String id, customer, mode, table, payment, status, date;
        double total; ArrayList<String> lines = new ArrayList<>();
        Order(String id,String customer,String mode,String table,String payment,double total,String date,ArrayList<String> lines){
            this.id=id;this.customer=customer;this.mode=mode;this.table=table;this.payment=payment;this.total=total;this.date=date;this.lines=lines;this.status="New";
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs=getSharedPreferences(PREF,MODE_PRIVATE);
        loadMenu();
        buildShell();
        showBilling();
        if(Build.VERSION.SDK_INT>=31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
    }

    private void buildShell(){
        ScrollView scroll=new ScrollView(this);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16),dp(14),dp(16),dp(22)); root.setBackgroundColor(0xFFF6F3FB);
        scroll.addView(root); setContentView(scroll);
        TextView title=new TextView(this); title.setText("SMART BILLING"); title.setTextSize(24); title.setTextColor(0xFFFFFFFF); title.setGravity(Gravity.CENTER_VERTICAL);
        title.setPadding(dp(14),dp(16),dp(14),dp(16)); title.setBackgroundColor(0xFF5426A8); root.addView(title);
        TextView subtitle=new TextView(this); subtitle.setText("Billing • Sales • SR588 Bluetooth Printer"); subtitle.setTextSize(13); subtitle.setPadding(0,dp(8),0,dp(10)); root.addView(subtitle);
        LinearLayout nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL);
        addButton(nav,"Billing",v->showBilling()); addButton(nav,"Menu",v->showMenu()); addButton(nav,"Orders",v->showOrders()); addButton(nav,"Printer",v->showPrinter());
        root.addView(nav);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content);
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density);}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(0xFF211A2E);t.setPadding(0,dp(5),0,dp(5));return t;}
    private EditText edit(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(10),dp(7),dp(10),dp(7));return e;}
    private Button button(String label, View.OnClickListener l){Button b=new Button(this);b.setText(label);b.setOnClickListener(l);return b;}
    private void addButton(LinearLayout row,String label,View.OnClickListener l){Button b=button(label,l);row.addView(b,new LinearLayout.LayoutParams(0,dp(48),1));}
    private void heading(String s){content.addView(text(s,20));}
    private void gap(){View v=new View(this);content.addView(v,new LinearLayout.LayoutParams(1,dp(8)));}
    private void loadMenu(){
        menu.clear();
        String saved=prefs==null?null:prefs.getString("menu",null);
        if(saved!=null && !saved.isEmpty()){
            try { for(String line:saved.split("\\n")){String[] p=line.split("\\|",4); if(p.length==4)menu.add(new Item(Integer.parseInt(p[0]),p[1],p[2],Double.parseDouble(p[3])));} }catch(Exception ignored){menu.clear();}
        }
        if(menu.isEmpty()){
            menu.add(new Item(1,"Chocolate Waffle","Waffles",49));
            menu.add(new Item(2,"Brownie","Desserts",79));
            menu.add(new Item(3,"Cold Coffee","Drinks",59));
            menu.add(new Item(4,"Veg Sandwich","Snacks",69));
        }
    }
    private void saveMenu(){
        StringBuilder s=new StringBuilder(); for(Item i:menu)s.append(i.id).append("|").append(i.name.replace("|"," ")).append("|").append(i.category.replace("|"," ")).append("|").append(i.price).append("\n");
        prefs.edit().putString("menu",s.toString()).apply();
    }
    private String rupee(double v){return "₹"+String.format(Locale.US,"%.2f",v).replace(".00","");}
    private double total(){double t=0;for(Item i:menu)t+=i.price*(cart.containsKey(i.id)?cart.get(i.id):0);return t;}
    private void showBilling(){
        content.removeAllViews(); cart.keySet().removeIf(id->menu.stream().noneMatch(i->i.id==id));
        heading("New Bill");
        shopName=edit("Shop name (e.g. Babe's Cafe)");shopName.setText(prefs.getString("shop",""));content.addView(shopName);
        customerName=edit("Customer name (optional)");content.addView(customerName);
        modeSpinner=new Spinner(this);modeSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Takeaway","Dine-in / Table"}));content.addView(modeSpinner);
        tableNo=edit("Table number (if dine-in)");content.addView(tableNo);
        for(Item i:menu){
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label=text(i.name+"\n"+rupee(i.price),15);row.addView(label,new LinearLayout.LayoutParams(0,dp(60),1));
            int q=cart.containsKey(i.id)?cart.get(i.id):0;
            row.addView(button("−",v->{cart.put(i.id,Math.max(0,(cart.containsKey(i.id)?cart.get(i.id):0)-1));showBilling();}));
            row.addView(text(" "+q+" ",15));
            row.addView(button("+",v->{cart.put(i.id,(cart.containsKey(i.id)?cart.get(i.id):0)+1);showBilling();}));
            content.addView(row);
        }
        paymentSpinner=new Spinner(this);paymentSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Cash","UPI QR (mark paid after checking payment)"}));content.addView(paymentSpinner);
        totalText=text("TOTAL: "+rupee(total()),22);content.addView(totalText);
        content.addView(button("Save Bill + Print",v->saveBill()));
        content.addView(button("Clear Cart",v->{cart.clear();showBilling();}));
    }
    private void saveBill(){
        if(total()<=0){toast("Add at least one item.");return;}
        String shop=shopName.getText().toString().trim();if(shop.isEmpty())shop="My Shop";prefs.edit().putString("shop",shop).apply();
        String mode=modeSpinner.getSelectedItemPosition()==0?"Takeaway":"Dine-in";
        String table=mode.equals("Dine-in")?tableNo.getText().toString().trim():"Pickup";
        if(mode.equals("Dine-in")&&table.isEmpty()){toast("Enter table number.");return;}
        String pay=paymentSpinner.getSelectedItemPosition()==0?"Cash":"UPI (verify manually)";
        String id="B"+new SimpleDateFormat("yyMMddHHmmss",Locale.US).format(new Date());
        String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date());
        ArrayList<String> lines=new ArrayList<>();for(Item i:menu){int q=cart.containsKey(i.id)?cart.get(i.id):0;if(q>0)lines.add(i.name+" x"+q+" = "+rupee(i.price*q));}
        Order o=new Order(id,customerName.getText().toString().trim(),mode,table,pay,total(),date,lines);orders.add(0,o);saveOrders();
        String receipt=receiptText(o,shop);cart.clear();
        new AlertDialog.Builder(this).setTitle("Bill saved").setMessage("Bill "+id+" saved.\nTotal: "+rupee(o.total)+"\nPrint now?").setNegativeButton("Later",(d,w)->showBilling()).setPositiveButton("Print",(d,w)->{printReceipt(receipt);showBilling();}).show();
    }
    private String receiptText(Order o,String shop){
        StringBuilder s=new StringBuilder();s.append(center(shop.toUpperCase(Locale.ROOT))).append("\n");
        s.append(center("BILL / RECEIPT")).append("\n--------------------------------\n");
        s.append("Bill: ").append(o.id).append("\n").append(o.date).append("\n");
        if(!o.customer.isEmpty())s.append("Customer: ").append(o.customer).append("\n");
        s.append(o.mode).append(": ").append(o.table).append("\n--------------------------------\n");
        for(String line:o.lines)s.append(line).append("\n");
        s.append("--------------------------------\nTOTAL: ").append(rupee(o.total)).append("\nPayment: ").append(o.payment).append("\n");
        s.append("--------------------------------\n").append(center("Thank you! Visit again.")).append("\n\n\n");
        return s.toString();
    }
    private String center(String s){return s;}
    private void showMenu(){
        content.removeAllViews();heading("Menu Management");
        content.addView(text("Add menu items or delete existing ones. Prices are saved on this phone.",13));
        EditText name=edit("Item name");content.addView(name);EditText cat=edit("Category");content.addView(cat);EditText price=edit("Price");price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);content.addView(price);
        content.addView(button("Add item",v->{try{String n=name.getText().toString().trim();double p=Double.parseDouble(price.getText().toString());if(n.isEmpty()||p<0)throw new Exception();menu.add(new Item((int)(System.currentTimeMillis()%2000000000),n,cat.getText().toString().trim().isEmpty()?"General":cat.getText().toString().trim(),p));saveMenu();showMenu();}catch(Exception e){toast("Enter item name and valid price.");}}));
        for(Item i:new ArrayList<>(menu)){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView t=text(i.name+" — "+rupee(i.price),14);r.addView(t,new LinearLayout.LayoutParams(0,dp(48),1));r.addView(button("Delete",v->{menu.removeIf(x->x.id==i.id);saveMenu();showMenu();}));content.addView(r);}
    }
    private void showOrders(){
        content.removeAllViews();heading("Bill History");
        if(orders.isEmpty()){content.addView(text("No bills saved yet on this app session.",14));return;}
        for(Order o:orders){content.addView(text(o.id+"  |  "+rupee(o.total)+"\n"+o.date+" • "+o.mode+" • "+o.payment+"\n"+String.join("\n",o.lines),14));content.addView(button("Reprint "+o.id,v->printReceipt(receiptText(o,prefs.getString("shop","My Shop")))));View line=new View(this);line.setBackgroundColor(0xFFE6DEEF);content.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));}
        content.addView(button("Clear history",v->new AlertDialog.Builder(this).setMessage("Clear all saved bills?").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{orders.clear();saveOrders();showOrders();}).show()));
    }
    private void saveOrders(){
        // Simple local persistence: one order per encoded line; avoids external database requirements.
        StringBuilder b=new StringBuilder();
        for(Order o:orders){b.append(Base64.getEncoder().encodeToString((o.id+"\t"+o.customer+"\t"+o.mode+"\t"+o.table+"\t"+o.payment+"\t"+o.total+"\t"+o.date+"\t"+String.join(";",o.lines)).getBytes(Charset.forName("UTF-8")))).append("\n");}
        prefs.edit().putString("orders",b.toString()).apply();
    }
    private void showPrinter(){
        content.removeAllViews();heading("Bluetooth Printer");
        printerStatus=text("Selected printer: "+connectedName,14);content.addView(printerStatus);
        content.addView(text("1. Turn on SR588.\n2. Pair it in Android Settings → Bluetooth.\n3. Tap Find paired printers below.",13));
        content.addView(button("Find paired printers",v->listPrinters()));
        content.addView(button("Connect selected printer",v->connectPrinter()));
        content.addView(button("Test print",v->printReceipt("SMART BILLING\nSR588 TEST PRINT\n58mm Bluetooth Printer\n\nIf this text prints, connection works.\n\n\n")));
        content.addView(button("Open Bluetooth settings",v->{try{startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS));}catch(Exception e){toast("Cannot open Bluetooth settings.");}}));
        content.addView(text("Note: printer must support Bluetooth Classic SPP and compatible ESC/POS text printing. Some SR588 variants may use a different protocol.",12));
    }
    private boolean hasBtPermission(){
        return Build.VERSION.SDK_INT<31 || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
    }
    private void listPrinters(){
        if(!hasBtPermission()){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null){toast("This phone has no Bluetooth adapter.");return;}
        Set<BluetoothDevice> devices;
        try{devices=a.getBondedDevices();}catch(SecurityException e){toast("Allow Nearby devices permission.");return;}
        if(devices.isEmpty()){toast("No paired devices. Pair SR588 in Android Settings first.");return;}
        ArrayList<BluetoothDevice> list=new ArrayList<>(devices);String[] names=new String[list.size()];
        for(int i=0;i<list.size();i++){BluetoothDevice d=list.get(i);names[i]=d.getName()+"\n"+d.getAddress();}
        new AlertDialog.Builder(this).setTitle("Select paired printer").setItems(names,(d,which)->{selectedPrinter=list.get(which);connectedName=selectedPrinter.getName();printerStatus.setText("Selected printer: "+connectedName);toast("Selected "+connectedName);}).show();
    }
    private void connectPrinter(){if(selectedPrinter==null){toast("First tap Find paired printers.");return;}toast("Printer selected. Test Print will attempt connection.");}
    private void printReceipt(String text){
        if(!hasBtPermission()){if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);return;}
        if(selectedPrinter==null){toast("Open Printer tab and select SR588 first.");return;}
        new Thread(()->{
            BluetoothSocket socket=null;
            try{
                UUID spp=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
                socket=selectedPrinter.createRfcommSocketToServiceRecord(spp);
                BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                socket.connect();OutputStream out=socket.getOutputStream();
                out.write(new byte[]{0x1B,0x40}); // ESC @ initialize
                out.write(text.getBytes(Charset.forName("GBK")));
                out.write(new byte[]{0x0A,0x0A,0x0A,0x1D,0x56,0x00}); // feed + partial cut where supported
                out.flush();socket.close();runOnUiThread(()->toast("Print data sent to "+connectedName));
            }catch(Exception e){try{if(socket!=null)socket.close();}catch(Exception ignored){}runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Print failed").setMessage("Could not print. Check printer power, paper, pairing and protocol.\n\n"+e.getMessage()).setPositiveButton("OK",null).show());}
        }).start();
    }
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==REQ_BT){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)toast("Bluetooth permission granted. Open Printer tab.");else toast("Bluetooth permission is required to print.");}}
}
